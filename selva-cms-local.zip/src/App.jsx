import React from 'react'

export default function App() {
  return (
    <div>
      <h1>Prof. Nadarajah CMS</h1>
      <p>Ready to add Base44 code...</p>
    </div>
  )
}
